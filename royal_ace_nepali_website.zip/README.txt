ROYAL ACE — नेपाली डेमो वेबसाइट

चलाउने तरिका:
1. ZIP extract गर्नुहोस्।
2. index.html लाई ब्राउजरमा खोल्नुहोस्।

समावेश:
- नेपाली भाषा र black/gold design
- Demo slots, cards र wheel
- Local demo register/login
- Admin dashboard demo

Demo admin login:
नाम: admin
पासवर्ड: royal-demo

सुरक्षा सीमा:
यो केवल front-end demo हो। पासवर्डहरू browser localStorage मा राखिन्छन्, त्यसैले यो वास्तविक खाताका लागि सुरक्षित छैन। सार्वजनिक/वास्तविक वेबसाइटका लागि backend, database, password hashing, secure sessions, rate limiting, privacy controls र कानुनी समीक्षा आवश्यक हुन्छ। कुनै वास्तविक पैसाको betting/deposit/withdrawal सुविधा छैन।
